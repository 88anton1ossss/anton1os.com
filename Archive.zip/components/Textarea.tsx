import React, { forwardRef, TextareaHTMLAttributes } from 'react';

interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  id: string;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ label, id, ...props }, ref) => {
    return (
      <div className="w-full">
        <label htmlFor={id} className="block text-sm font-medium text-stone mb-2">
          {label}
        </label>
        <textarea
          ref={ref}
          id={id}
          rows={4}
          {...props}
          className="w-full p-3 bg-white border border-alpine-dark border-opacity-10 rounded-base shadow-soft text-alpine-dark placeholder:text-stone focus:outline-none focus:ring-2 focus:ring-glacial-blue"
        />
      </div>
    );
  }
);

Textarea.displayName = 'Textarea';
