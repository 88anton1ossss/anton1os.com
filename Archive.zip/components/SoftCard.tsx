import React, { ReactNode, ElementType } from 'react';

interface SoftCardProps {
  children: ReactNode;
  className?: string;
  as?: ElementType;
}

export function SoftCard({ children, className = "", as = "div" }: SoftCardProps) {
  const Tag = as;
  return (
    <Tag
      className={`bg-white border border-alpine-dark border-opacity-5 shadow-soft rounded-soft p-6 md:p-8 ${className}`}
    >
      {children}
    </Tag>
  );
}
