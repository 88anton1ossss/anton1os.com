import React, { useState, ReactNode } from 'react';
import { ChevronUp, ChevronDown } from 'lucide-react';

interface AccordionItemProps {
  title: string;
  children: ReactNode;
}

export function AccordionItem({ title, children }: AccordionItemProps) {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="border-b border-alpine-dark border-opacity-10">
      <h3>
        <button
          onClick={() => setIsOpen(!isOpen)}
          aria-expanded={isOpen}
          aria-controls={`accordion-panel-${title}`}
          id={`accordion-button-${title}`}
          className="flex justify-between items-center w-full py-5 text-left font-body font-semibold text-lg"
        >
          <span>{title}</span>
          {isOpen ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
        </button>
      </h3>
      <div
        id={`accordion-panel-${title}`}
        role="region"
        aria-labelledby={`accordion-button-${title}`}
        hidden={!isOpen}
        className="pb-5 pr-10 text-stone"
      >
        {children}
      </div>
    </div>
  );
}
