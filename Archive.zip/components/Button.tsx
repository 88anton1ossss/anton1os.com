import React, { ReactNode } from 'react';

interface ButtonProps {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'ghost';
  size?: 'base' | 'lg';
  as?: 'button' | 'a';
  href?: string;
  target?: string;
  className?: string;
  iconLeft?: ReactNode;
  type?: 'button' | 'submit' | 'reset';
  disabled?: boolean;
}

export function Button({
  children,
  onClick,
  variant = "primary",
  size = "base",
  as = "button",
  href,
  target,
  className = "",
  iconLeft,
  type = "button",
  disabled = false,
}: ButtonProps) {
  const baseStyles =
    "inline-flex items-center justify-center gap-2 font-body font-semibold uppercase tracking-wider transition-all duration-300 rounded-base focus-visible:outline-glacial-blue focus-visible:outline-offset-2 disabled:opacity-50 disabled:cursor-not-allowed";

  const variantStyles = {
    primary:
      "bg-glacial-blue text-snow hover:opacity-85 shadow-soft",
    secondary:
      "bg-transparent border border-glacial-blue text-glacial-blue hover:bg-glacial-blue hover:text-snow",
    ghost:
      "bg-transparent text-alpine-dark hover:bg-snow hover:bg-opacity-70"
  };

  const sizeStyles = {
    base: "py-3 px-6 text-sm",
    lg: "py-4 px-8 text-base",
  };

  const Tag = as;

  return (
    <Tag
      href={href}
      target={target}
      rel={target === "_blank" ? "noopener noreferrer" : undefined}
      onClick={onClick}
      type={as === 'button' ? type : undefined}
      disabled={disabled}
      className={`${baseStyles} ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}
    >
      {iconLeft && <span className="w-5 h-5">{iconLeft}</span>}
      {children}
    </Tag>
  );
}
