import React, { ReactNode, ElementType } from 'react';

interface SectionProps {
  children: ReactNode;
  className?: string;
  as?: ElementType;
  id?: string;
}

export function Section({ children, className = "", as = "section", id }: SectionProps) {
  const Tag = as;
  return (
    <Tag
      id={id}
      className={`w-full py-16 md:py-24 px-6 lg:px-12 ${className}`}
    >
      <div className="max-w-6xl mx-auto">{children}</div>
    </Tag>
  );
}
