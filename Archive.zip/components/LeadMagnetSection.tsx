import React, { useState } from 'react';
import { Section } from './Section';
import { Button } from './Button';
import { Input } from './Input';

export function LeadMagnetSection() {
  const [email, setEmail] = useState('');
  const [firstName, setFirstName] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Lead captured:', { email, firstName });
    // TODO: Integrate with email service (Mailchimp, ConvertKit, etc.)
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <Section className="bg-glacial-blue text-center text-snow">
        <div className="max-w-2xl mx-auto py-8">
          <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-glacial-blue" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h3 className="text-3xl font-heading font-bold mb-2">Check Your Email!</h3>
          <p className="text-lg">Your free guide is on its way to <span className="font-bold">{email}</span></p>
        </div>
      </Section>
    );
  }

  return (
    <Section className="bg-gradient-to-r from-glacial-blue to-alpine-dark text-snow">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        {/* Left Side: Content */}
        <div>
          <span className="inline-block bg-white bg-opacity-20 text-snow text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full mb-4">
            Free Guide
          </span>
          <h3 className="text-3xl md:text-4xl font-heading font-bold mb-4">
            Planning a Proposal?
          </h3>
          <p className="text-lg mb-6 text-snow text-opacity-90">
            Don't propose by the main lift. Get my <span className="font-bold">FREE guide</span> to the 5 most cinematic (and secret) proposal spots on the mountain.
          </p>

          {/* Preview Image */}
          <div className="mb-6 rounded-base overflow-hidden shadow-glass border-2 border-white border-opacity-30">
            <img 
              src="https://images.unsplash.com/photo-1517042562200-a6a3aba4004c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
              alt="The 5 Secret Proposal Spots Guide Preview"
              className="w-full h-48 object-cover"
            />
            <div className="bg-white text-alpine-dark text-center py-3 font-heading font-bold">
              📍 The 5 Secret Proposal Spots
            </div>
          </div>
        </div>

        {/* Right Side: Form */}
        <div className="bg-white text-alpine-dark rounded-soft p-8 shadow-glass">
          <h4 className="text-2xl font-heading font-bold mb-6 text-center">
            Get Your Free Guide
          </h4>
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="First Name"
              id="firstName-section"
              type="text"
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              placeholder="e.g., Michael"
              required
            />
            <Input
              label="Email Address"
              id="email-section"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="e.g., michael@example.com"
              required
            />
            <Button type="submit" variant="primary" size="lg" className="w-full">
              Get The Free Guide
            </Button>
          </form>

          <p className="text-xs text-stone mt-4 text-center">
            I respect your privacy. Unsubscribe anytime. No spam, just epic proposal tips.
          </p>

          {/* Trust Indicators */}
          <div className="mt-6 pt-6 border-t border-alpine-dark border-opacity-10 flex items-center justify-center gap-8 text-sm text-stone">
            <div className="flex items-center gap-2">
              <svg className="w-4 h-4 text-glacial-blue" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
              </svg>
              <span>Secure</span>
            </div>
            <div className="flex items-center gap-2">
              <svg className="w-4 h-4 text-glacial-blue" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              <span>No Spam</span>
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
}
