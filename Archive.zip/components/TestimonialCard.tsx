import React from 'react';
import { Star, MapPin, Calendar } from 'lucide-react';
import { Testimonial } from '../data/testimonials';
import { SoftCard } from './SoftCard';

interface TestimonialCardProps {
  testimonial: Testimonial;
}

export function TestimonialCard({ testimonial }: TestimonialCardProps) {
  return (
    <SoftCard className="flex flex-col h-full">
      {/* Photo */}
      <div className="relative -m-6 md:-m-8 mb-6 h-64 overflow-hidden rounded-t-soft">
        <img 
          src={testimonial.photo} 
          alt={`${testimonial.name} at ${testimonial.resort}`}
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
        />
        <div className="absolute top-4 right-4 bg-white rounded-full px-3 py-1 shadow-soft">
          <span className="text-xs font-semibold text-glacial-blue">{testimonial.type}</span>
        </div>
      </div>

      {/* Content */}
      <div className="flex flex-col flex-grow">
        {/* Rating */}
        <div className="flex gap-1 mb-4">
          {[...Array(5)].map((_, i) => (
            <Star key={i} size={18} className="fill-glacial-blue text-glacial-blue" />
          ))}
        </div>

        {/* Review */}
        <p className="text-stone mb-6 flex-grow italic">
          "{testimonial.review}"
        </p>

        {/* Customer Info */}
        <div className="flex items-center gap-4 pt-4 border-t border-alpine-dark border-opacity-5">
          {testimonial.customerPhoto && (
            <img 
              src={testimonial.customerPhoto} 
              alt={testimonial.name}
              className="w-12 h-12 rounded-full object-cover"
            />
          )}
          <div className="flex-grow">
            <h4 className="font-heading font-bold text-alpine-dark">{testimonial.name}</h4>
            <div className="flex flex-col gap-1 mt-1">
              <div className="flex items-center gap-1 text-xs text-stone">
                <MapPin size={12} />
                <span>{testimonial.location} • {testimonial.resort}</span>
              </div>
              <div className="flex items-center gap-1 text-xs text-stone">
                <Calendar size={12} />
                <span>{testimonial.date}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </SoftCard>
  );
}