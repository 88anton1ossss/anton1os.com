import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { useNavigation, navLinks } from '../contexts/NavigationContext';
import { Button } from './Button';

export function Header() {
  const { navigate } = useNavigation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const NavButton = ({ to, children }: { to: string; children: React.ReactNode }) => (
    <button
      onClick={() => {
        navigate(to as any);
        setIsMobileMenuOpen(false);
      }}
      className="py-2 text-stone hover:text-glacial-blue transition-colors duration-300 md:py-0 md:px-4"
    >
      {children}
    </button>
  );

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-all duration-300 ${
        isScrolled ? "bg-snow shadow-soft" : "bg-transparent"
      }`}
    >
      <nav
        className="max-w-6xl mx-auto flex items-center justify-between p-6 lg:px-12"
        aria-label="Main navigation"
      >
        {/* Logo */}
        <button
          onClick={() => navigate("home")}
          className="text-2xl font-heading font-bold uppercase tracking-wider text-alpine-dark"
          aria-label="anton1os.com - Go to Homepage"
        >
          ANTON1OS
        </button>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-2">
          {navLinks.map((link) => (
            <NavButton key={link.path} to={link.path}>
              {link.title}
            </NavButton>
          ))}
          <Button
            onClick={() => navigate("contact")}
            variant="secondary"
            size="base"
            className="ml-4"
          >
            Book Now
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <button
            onClick={() => setIsMobileMenuOpen(true)}
            aria-label="Open main menu"
            aria-expanded={isMobileMenuOpen}
            aria-controls="mobile-menu"
            className="p-2"
          >
            <Menu size={24} />
          </button>
        </div>
      </nav>

      {/* Mobile Menu Panel */}
      {isMobileMenuOpen && (
        <div
          id="mobile-menu"
          className="fixed inset-0 z-50 bg-snow md:hidden"
          role="dialog"
          aria-modal="true"
        >
          <div className="p-6">
            <div className="flex items-center justify-between">
              <span className="text-2xl font-heading font-bold uppercase tracking-wider text-alpine-dark">
                ANTON1OS
              </span>
              <button
                onClick={() => setIsMobileMenuOpen(false)}
                aria-label="Close main menu"
                className="p-2"
              >
                <X size={24} />
              </button>
            </div>
            <div className="mt-8 flex flex-col items-start gap-4">
              {navLinks.map((link) => (
                <NavButton key={link.path} to={link.path}>
                  <span className="text-xl">{link.title}</span>
                </NavButton>
              ))}
              <Button
                onClick={() => {
                  navigate("contact");
                  setIsMobileMenuOpen(false);
                }}
                variant="primary"
                size="base"
                className="mt-4 w-full"
              >
                Book Your Adventure
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
