import React from 'react';
import { Check } from 'lucide-react';
import { Package } from '../data/packages';
import { SoftCard } from './SoftCard';
import { Button } from './Button';

interface PackageCardProps {
  pkg: Package;
  ctaText?: string;
  onCtaClick: () => void;
  isFeatured?: boolean;
}

export function PackageCard({ pkg, ctaText = "Book This Package", onCtaClick, isFeatured = false }: PackageCardProps) {
  return (
    <SoftCard
      className={`flex flex-col h-full ${
        isFeatured ? "border-2 border-glacial-blue" : ""
      }`}
      as="article"
    >
      {isFeatured && (
        <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-glacial-blue text-snow text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full">
          Most Popular
        </span>
      )}
      <div className="text-center">
        <h3 className="text-2xl font-heading font-bold">{pkg.name}</h3>
        <p className="text-stone mt-2 text-sm">{pkg.idealFor}</p>
        <div className="text-5xl font-heading font-bold text-glacial-blue my-6">
          ${pkg.price}
          <span className="text-base font-body text-stone font-normal">
            {" "}/{pkg.pricePer}
          </span>
        </div>
      </div>
      <ul className="space-y-3 mb-8 flex-grow">
        {pkg.features.map((feature, i) => (
          <li key={i} className="flex items-start gap-3">
            <Check size={20} className="text-glacial-blue flex-shrink-0 mt-1" />
            <span className="text-stone">{feature}</span>
          </li>
        ))}
      </ul>
      <Button onClick={onCtaClick} variant={isFeatured ? "primary" : "secondary"} className="w-full">
        {ctaText}
      </Button>
    </SoftCard>
  );
}
