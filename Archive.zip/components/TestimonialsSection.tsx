import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';
import { Section } from './Section';
import { SectionHeader } from './SectionHeader';
import { TestimonialCard } from './TestimonialCard';
import { testimonialsData } from '../data/testimonials';

export function TestimonialsSection() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const testimonialsPerPage = 3;
  const maxIndex = Math.max(0, testimonialsData.length - testimonialsPerPage);

  const next = () => {
    setCurrentIndex(prev => Math.min(prev + 1, maxIndex));
  };

  const prev = () => {
    setCurrentIndex(prev => Math.max(prev - 1, 0));
  };

  const visibleTestimonials = testimonialsData.slice(
    currentIndex,
    currentIndex + testimonialsPerPage
  );

  // Calculate average rating and total reviews
  const totalReviews = testimonialsData.length;
  const avgRating = (testimonialsData.reduce((sum, t) => sum + t.rating, 0) / totalReviews).toFixed(1);

  return (
    <Section id="testimonials" className="bg-gradient-to-b from-white to-snow">
      <div className="text-center mb-12">
        <SectionHeader title="What Adventurers Are Saying" subtitle="Reviews" />
        
        {/* Rating Summary */}
        <div className="flex items-center justify-center gap-3 mt-6">
          <div className="flex gap-1">
            {[...Array(5)].map((_, i) => (
              <Star key={i} size={24} className="fill-glacial-blue text-glacial-blue" />
            ))}
          </div>
          <span className="text-2xl font-heading font-bold text-alpine-dark">{avgRating}</span>
          <span className="text-stone">({totalReviews} reviews)</span>
        </div>
      </div>

      {/* Testimonials Grid */}
      <div className="relative">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 stagger-children">
          {visibleTestimonials.map((testimonial) => (
            <TestimonialCard key={testimonial.id} testimonial={testimonial} />
          ))}
        </div>

        {/* Navigation Arrows */}
        {testimonialsData.length > testimonialsPerPage && (
          <div className="flex items-center justify-center gap-4 mt-12">
            <button
              onClick={prev}
              disabled={currentIndex === 0}
              className="p-3 rounded-full bg-white border border-alpine-dark border-opacity-10 shadow-soft hover:bg-glacial-blue hover:text-snow transition-all disabled:opacity-30 disabled:cursor-not-allowed disabled:hover:bg-white disabled:hover:text-alpine-dark"
              aria-label="Previous testimonials"
            >
              <ChevronLeft size={24} />
            </button>

            {/* Dots */}
            <div className="flex gap-2">
              {[...Array(maxIndex + 1)].map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentIndex(i)}
                  className={`w-2 h-2 rounded-full transition-all ${
                    i === currentIndex 
                      ? 'bg-glacial-blue w-8' 
                      : 'bg-alpine-dark bg-opacity-20 hover:bg-opacity-40'
                  }`}
                  aria-label={`Go to page ${i + 1}`}
                />
              ))}
            </div>

            <button
              onClick={next}
              disabled={currentIndex === maxIndex}
              className="p-3 rounded-full bg-white border border-alpine-dark border-opacity-10 shadow-soft hover:bg-glacial-blue hover:text-snow transition-all disabled:opacity-30 disabled:cursor-not-allowed disabled:hover:bg-white disabled:hover:text-alpine-dark"
              aria-label="Next testimonials"
            >
              <ChevronRight size={24} />
            </button>
          </div>
        )}
      </div>

      {/* Trust Badges */}
      <div className="mt-16 pt-12 border-t border-alpine-dark border-opacity-5">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div>
            <div className="text-4xl font-heading font-bold text-glacial-blue">50+</div>
            <div className="text-sm text-stone mt-2">Proposals Captured</div>
          </div>
          <div>
            <div className="text-4xl font-heading font-bold text-glacial-blue">200+</div>
            <div className="text-sm text-stone mt-2">Happy Clients</div>
          </div>
          <div>
            <div className="text-4xl font-heading font-bold text-glacial-blue">100%</div>
            <div className="text-sm text-stone mt-2">5-Star Reviews</div>
          </div>
          <div>
            <div className="text-4xl font-heading font-bold text-glacial-blue">72hr</div>
            <div className="text-sm text-stone mt-2">Delivery Guarantee</div>
          </div>
        </div>
      </div>
    </Section>
  );
}
