import { useEffect } from 'react';
import { Page } from '../contexts/NavigationContext';

interface SEOProps {
  page: Page;
}

const pageMetadata: Record<Page, {
  title: string;
  description: string;
  keywords: string;
}> = {
  home: {
    title: "Anton Egorov | Colorado Ski & Proposal Photographer | Winter Park",
    description: "Capture your Colorado ski trip or proposal. I'm an on-mountain photographer (and Ikon Pass holder!) in Winter Park & Copper. Stop taking ugly selfies. Book your adventure.",
    keywords: "colorado ski photographer, mountain proposal photographer, winter park photographer, ikon pass photographer, ski engagement photos, snowboard photography, adventure photography colorado"
  },
  packages: {
    title: "Photography Packages & Pricing - Anton1os",
    description: "Transparent pricing for mountain photography sessions. Solo adventures, couple sessions, and secret proposals. 72-hour delivery guarantee. Book your Colorado ski photographer today.",
    keywords: "ski photography packages, mountain photography pricing, proposal photography cost, colorado photographer rates, ski session pricing"
  },
  portfolio: {
    title: "Portfolio - Mountain Photography by Anton1os",
    description: "View stunning mountain adventure photography from Colorado's top ski resorts. Proposals, couples, action shots, and authentic moments captured at Winter Park, Copper, and A-Basin.",
    keywords: "ski photography portfolio, mountain photography examples, colorado ski photos, winter engagement photos, snowboard photography"
  },
  experience: {
    title: "The Experience - What to Expect | Anton1os Photography",
    description: "Learn about the anton1os photography experience. From planning call to 72-hour delivery, discover how we capture authentic adventure moments on the mountain.",
    keywords: "ski photography experience, mountain photo session, what to expect photography, colorado ski photographer process"
  },
  blog: {
    title: "Blog - Ski Photography Tips & Guides | Anton1os",
    description: "Expert guides on Colorado ski photography, proposal planning, and mountain adventures. Tips from a professional photographer with Ikon Pass access.",
    keywords: "ski photography tips, mountain proposal ideas, winter photography guide, colorado ski resort guide, photography blog"
  },
  'blog-post': {
    title: "Blog Post - Anton1os Photography",
    description: "Read insights, tips, and guides about mountain photography and Colorado ski adventures.",
    keywords: "ski photography, mountain adventures, colorado guide"
  },
  'ai-tools': {
    title: "AI Tools - Proposal Ideas & Caption Generator | Anton1os",
    description: "Free AI-powered tools for planning your mountain proposal and creating Instagram captions. Get custom ideas from a professional ski photographer.",
    keywords: "proposal idea generator, instagram caption generator, mountain proposal ideas, ai photography tools"
  },
  about: {
    title: "About Anton - Your Colorado Adventure Photographer",
    description: "Meet Anton: snowboarder, backpacker, and adventure photographer. 10+ years documenting Colorado's mountains with Ikon Pass expertise and backcountry knowledge.",
    keywords: "about anton1os, colorado photographer bio, ski photographer background, adventure photographer story"
  },
  contact: {
    title: "Contact & Book Your Session - Anton1os Photography",
    description: "Book your Colorado mountain photography session. Check availability for Winter Park, Copper Mountain, and A-Basin. Free consultation. 24-hour response time.",
    keywords: "book ski photographer, contact colorado photographer, schedule mountain photography, photography inquiry"
  }
};

export function SEO({ page }: SEOProps) {
  useEffect(() => {
    const metadata = pageMetadata[page];
    
    // Update title
    document.title = metadata.title;
    
    // Update meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', metadata.description);
    } else {
      const newMeta = document.createElement('meta');
      newMeta.name = 'description';
      newMeta.content = metadata.description;
      document.head.appendChild(newMeta);
    }
    
    // Update meta keywords
    const metaKeywords = document.querySelector('meta[name="keywords"]');
    if (metaKeywords) {
      metaKeywords.setAttribute('content', metadata.keywords);
    } else {
      const newMeta = document.createElement('meta');
      newMeta.name = 'keywords';
      newMeta.content = metadata.keywords;
      document.head.appendChild(newMeta);
    }
    
    // Update Open Graph tags
    updateMetaTag('og:title', metadata.title);
    updateMetaTag('og:description', metadata.description);
    updateMetaTag('og:type', 'website');
    updateMetaTag('og:url', `https://anton1os.com/${page === 'home' ? '' : page}`);
    updateMetaTag('og:image', 'https://anton1os.com/og-image.jpg');
    
    // Update Twitter Card tags
    updateMetaTag('twitter:card', 'summary_large_image', 'name');
    updateMetaTag('twitter:title', metadata.title, 'name');
    updateMetaTag('twitter:description', metadata.description, 'name');
    updateMetaTag('twitter:image', 'https://anton1os.com/og-image.jpg', 'name');
    
  }, [page]);
  
  return null;
}

function updateMetaTag(property: string, content: string, attributeName: string = 'property') {
  let meta = document.querySelector(`meta[${attributeName}="${property}"]`);
  if (meta) {
    meta.setAttribute('content', content);
  } else {
    const newMeta = document.createElement('meta');
    newMeta.setAttribute(attributeName, property);
    newMeta.content = content;
    document.head.appendChild(newMeta);
  }
}