import React, { forwardRef, InputHTMLAttributes } from 'react';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  id: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, id, type = "text", ...props }, ref) => {
    return (
      <div className="w-full">
        <label htmlFor={id} className="block text-sm font-medium text-stone mb-2">
          {label}
        </label>
        <input
          ref={ref}
          type={type}
          id={id}
          {...props}
          className="w-full p-3 bg-white border border-alpine-dark border-opacity-10 rounded-base shadow-soft text-alpine-dark placeholder:text-stone focus:outline-none focus:ring-2 focus:ring-glacial-blue"
        />
      </div>
    );
  }
);

Input.displayName = 'Input';
