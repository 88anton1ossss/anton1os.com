import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Button } from './Button';
import { Input } from './Input';

export function LeadMagnetModal() {
  const [isVisible, setIsVisible] = useState(false);
  const [email, setEmail] = useState('');
  const [firstName, setFirstName] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    let hasShown = false;

    const handleMouseLeave = (e: MouseEvent) => {
      // Trigger when mouse leaves viewport from top
      if (e.clientY <= 0 && !hasShown) {
        const alreadyDismissed = sessionStorage.getItem('leadMagnetDismissed');
        if (!alreadyDismissed) {
          setIsVisible(true);
          hasShown = true;
        }
      }
    };

    document.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      document.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);

  const handleClose = () => {
    setIsVisible(false);
    sessionStorage.setItem('leadMagnetDismissed', 'true');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Lead captured:', { email, firstName });
    // TODO: Integrate with email service (Mailchimp, ConvertKit, etc.)
    setIsSubmitted(true);
    
    // Close after 2 seconds
    setTimeout(() => {
      handleClose();
    }, 2000);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-alpine-dark bg-opacity-75 backdrop-blur-sm animate-fade-in">
      <div className="relative bg-white rounded-soft shadow-glass max-w-lg w-full mx-4 p-8 md:p-12 animate-scale-in">
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 text-stone hover:text-alpine-dark transition-colors"
          aria-label="Close modal"
        >
          <X size={24} />
        </button>

        {!isSubmitted ? (
          <>
            {/* Headline */}
            <h3 className="text-3xl font-heading font-bold text-alpine-dark mb-4">
              Planning a Proposal?
            </h3>

            {/* Body Text */}
            <p className="text-stone mb-6 text-lg">
              Don't propose by the main lift. Get my <span className="font-bold text-glacial-blue">FREE guide</span> to the 5 most cinematic (and secret) proposal spots on the mountain.
            </p>

            {/* Image Preview */}
            <div className="mb-6 rounded-base overflow-hidden shadow-soft">
              <img 
                src="https://images.unsplash.com/photo-1517042562200-a6a3aba4004c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                alt="The 5 Secret Proposal Spots Guide Preview"
                className="w-full h-48 object-cover"
              />
              <div className="bg-glacial-blue text-white text-center py-3 font-heading font-bold">
                📍 The 5 Secret Proposal Spots
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                label="First Name"
                id="firstName"
                type="text"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                placeholder="e.g., Michael"
                required
              />
              <Input
                label="Email"
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="e.g., michael@example.com"
                required
              />
              <Button type="submit" variant="primary" size="lg" className="w-full">
                Get The Free Guide
              </Button>
            </form>

            {/* Privacy Note */}
            <p className="text-xs text-stone mt-4 text-center">
              I respect your privacy. Unsubscribe anytime. No spam, just epic proposal tips.
            </p>
          </>
        ) : (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-glacial-blue rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h3 className="text-2xl font-heading font-bold text-alpine-dark mb-2">
              Check Your Email!
            </h3>
            <p className="text-stone">
              Your free guide is on its way to <span className="font-bold">{email}</span>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
