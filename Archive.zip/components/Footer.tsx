import React from 'react';
import { Instagram, Mail } from 'lucide-react';
import { useNavigation, navLinks } from '../contexts/NavigationContext';
import { Button } from './Button';

export function Footer() {
  const { navigate } = useNavigation();
  return (
    <footer className="bg-alpine-dark text-snow" aria-labelledby="footer-heading">
      <div className="max-w-6xl mx-auto py-16 px-6 lg:px-12">
        <h2 id="footer-heading" className="sr-only">Footer</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Column 1: Brand & Social */}
          <div className="flex flex-col">
            <span className="text-3xl font-heading font-bold uppercase tracking-wider">
              ANTON1OS
            </span>
            <p className="mt-4 text-stone max-w-xs">
              Colorado's On-Mountain Proposal & Adventure Photographer.
            </p>
            <div className="flex gap-4 mt-6">
              <a
                href="https://instagram.com/anton1os"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Follow on Instagram"
                className="flex items-center justify-center w-10 h-10 rounded-full bg-snow bg-opacity-10 transition-colors"
              >
                <Instagram size={20} className="text-snow" />
              </a>
              <a
                href="mailto:anton@anton1os.com"
                aria-label="Email me"
                className="flex items-center justify-center w-10 h-10 rounded-full bg-snow bg-opacity-10 transition-colors"
              >
                <Mail size={20} className="text-snow" />
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider">
              Quick Links
            </h3>
            <ul className="mt-4 space-y-3">
              {[...navLinks, { title: "Contact", path: "contact" as const }].map(
                (link) => (
                  <li key={link.path}>
                    <button
                      onClick={() => navigate(link.path)}
                      className="text-stone hover:text-glacial-blue transition-colors"
                    >
                      {link.title}
                    </button>
                  </li>
                )
              )}
            </ul>
          </div>

          {/* Column 3: Contact */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider">
              Get In Touch
            </h3>
            <p className="mt-4 text-stone">
              Based in Parker, CO.
              <br />
              Serving all Ikon Pass resorts including Winter Park, Copper, and A-Basin.
            </p>
            <Button
              onClick={() => navigate("contact")}
              variant="primary"
              className="mt-6"
            >
              Book Now
            </Button>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-snow border-opacity-10 text-center text-stone text-sm">
          <p>&copy; {new Date().getFullYear()} anton1os.com. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}