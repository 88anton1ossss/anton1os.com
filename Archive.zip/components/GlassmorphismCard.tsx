import React, { ReactNode } from 'react';

interface GlassmorphismCardProps {
  children: ReactNode;
  className?: string;
}

export function GlassmorphismCard({ children, className = "" }: GlassmorphismCardProps) {
  return (
    <div
      className={`bg-glass backdrop-blur-xl saturate-150 border border-white border-opacity-50 rounded-soft shadow-glass p-8 md:p-12 ${className}`}
    >
      {children}
    </div>
  );
}
