import React from 'react';
import { BlogPost } from '../data/blog';
import { useNavigation } from '../contexts/NavigationContext';
import { SoftCard } from './SoftCard';
import { Button } from './Button';

interface BlogCardProps {
  post: BlogPost;
}

export function BlogCard({ post }: BlogCardProps) {
  const { navigate } = useNavigation();
  return (
    <SoftCard
      as="article"
      aria-labelledby={`blog-title-${post.id}`}
      className="flex flex-col h-full overflow-hidden"
    >
      <img src={post.imageUrl} alt={post.title} className="w-full h-48 object-cover -m-6 md:-m-8" />
      <div className="flex flex-col flex-grow pt-48">
        <div className="mb-4 mt-6">
          <span className="text-xs font-semibold uppercase tracking-wider text-glacial-blue">{post.category}</span>
          <span className="text-xs text-stone float-right">{post.date}</span>
        </div>
        <h3 id={`blog-title-${post.id}`} className="text-xl font-heading font-bold mb-3">{post.title}</h3>
        <p className="text-stone mb-6 flex-grow">{post.snippet}</p>
        <Button
          onClick={() => navigate('blog-post', { id: post.id })}
          variant="secondary"
          className="w-full"
        >
          Read More
        </Button>
      </div>
    </SoftCard>
  );
}
