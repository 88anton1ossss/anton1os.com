import React from 'react';

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  align?: 'left' | 'center';
}

export function SectionHeader({ title, subtitle, align = "center" }: SectionHeaderProps) {
  const alignClass = align === "center" ? "text-center mx-auto" : "text-left";
  return (
    <div className={`max-w-3xl mb-12 md:mb-16 ${alignClass}`}>
      {subtitle && (
        <span className="text-sm font-semibold uppercase tracking-widest text-glacial-blue">
          {subtitle}
        </span>
      )}
      <h2 className="text-3xl md:text-5xl font-heading font-bold mt-2">
        {title}
      </h2>
    </div>
  );
}
