import React from 'react';
import { useNavigation } from '../contexts/NavigationContext';
import { Section } from '../components/Section';
import { SoftCard } from '../components/SoftCard';
import { Button } from '../components/Button';
import { blogPostsData } from '../data/blog';

export function BlogPostPage() {
  const { pageParams, navigate } = useNavigation();
  const post = blogPostsData.find(p => p.id === pageParams.id);

  if (!post) {
    return <Section><p>Blog post not found.</p></Section>;
  }

  return (
    <main>
      <div className="relative w-full h-[60vh]">
        <img src={post.imageUrl} alt={post.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-alpine-dark opacity-50"></div>
      </div>
      <Section className="relative -mt-32 z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          <div className="lg:col-span-8">
            <SoftCard>
              <div className="text-center mb-8">
                <span className="text-sm font-semibold uppercase tracking-widest text-glacial-blue">{post.category}</span>
                <h1 className="text-3xl md:text-5xl font-heading font-bold mt-2">{post.title}</h1>
                <p className="text-stone mt-4">{post.date}</p>
              </div>
              <div
                className="prose prose-lg max-w-none text-alpine-dark prose-headings:font-heading prose-h3:font-bold prose-h3:text-2xl"
                dangerouslySetInnerHTML={{ __html: post.content }}
              />
            </SoftCard>
          </div>
          <div className="lg:col-span-4">
            <div className="sticky top-24 space-y-8">
              <SoftCard className="bg-alpine-dark text-snow text-center">
                <h3 className="text-2xl font-heading font-bold mb-4">Ready for Your Adventure?</h3>
                <p className="text-stone mb-6">Let's capture your story.</p>
                <Button onClick={() => navigate('contact')} variant="primary" className="w-full">
                  Book Now
                </Button>
              </SoftCard>
              <SoftCard>
                <h3 className="text-xl font-heading font-bold mb-4">Recent Posts</h3>
                <ul className="space-y-3">
                  {blogPostsData.slice(0, 3).map(p => (
                    <li key={p.id}>
                      <button
                        onClick={() => navigate('blog-post', { id: p.id })}
                        className="text-stone hover:text-glacial-blue transition-colors text-left"
                      >
                        {p.title}
                      </button>
                    </li>
                  ))}
                </ul>
              </SoftCard>
            </div>
          </div>
        </div>
      </Section>
    </main>
  );
}
