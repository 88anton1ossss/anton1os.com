import React, { useState, useReducer, useEffect } from 'react';
import { Plus, Minus } from 'lucide-react';
import { useNavigation } from '../contexts/NavigationContext';
import { Section } from '../components/Section';
import { SectionHeader } from '../components/SectionHeader';
import { SoftCard } from '../components/SoftCard';
import { Button } from '../components/Button';
import { PackageCard } from '../components/PackageCard';
import { LeadMagnetSection } from '../components/LeadMagnetSection';
import { packagesData, addonsData, Addon } from '../data/packages';

function calculatorReducer(state: Addon[], action: { type: string; id: string }) {
  const item = state.find(item => item.id === action.id);
  if (!item) return state;
  
  switch (action.type) {
    case 'increment':
      if (item.quantity < item.max) {
        return state.map(item =>
          item.id === action.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return state;
    case 'decrement':
      if (item.quantity > 0) {
        return state.map(item =>
          item.id === action.id ? { ...item, quantity: item.quantity - 1 } : item
        );
      }
      return state;
    case 'toggle':
        return state.map(item =>
          item.id === action.id ? { ...item, quantity: item.quantity === 0 ? 1 : 0 } : item
        );
    default:
      return state;
  }
}

export function PackagesPage() {
  const { navigate, pageParams } = useNavigation();
  const [addons, dispatch] = useReducer(calculatorReducer, addonsData);
  const [basePrice] = useState(450);
  
  useEffect(() => {
    if (pageParams.scrollTo) {
      setTimeout(() => {
        document.getElementById(pageParams.scrollTo)?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  }, [pageParams]);

  const totalAddonsPrice = addons.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const totalPrice = basePrice + totalAddonsPrice;

  const handleCtaClick = (pkg: any) => {
    navigate('contact', { package: pkg.name });
  };
  
  return (
    <main>
      <Section id="packages-hero" className="text-center">
        <SectionHeader title="Find Your Adventure" subtitle="Packages & Pricing" />
        <p className="text-lg text-stone max-w-2xl mx-auto">
          Clear, simple pricing for epic moments. No hidden fees. Just you, the mountains, and your story.
        </p>
      </Section>

      <Section id="core-packages" className="bg-white">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {packagesData.map((pkg) => (
            <div id={pkg.id} key={pkg.id}>
              <PackageCard
                pkg={pkg}
                onCtaClick={() => handleCtaClick(pkg)}
                isFeatured={pkg.isFeatured}
              />
            </div>
          ))}
        </div>
      </Section>
      
      <Section id="build-your-own">
        <SectionHeader title="Build Your Own Adventure" subtitle="Custom Calculator" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <SoftCard>
            <h3 className="text-2xl font-heading font-bold mb-6">Customize Your Session</h3>
            <div className="space-y-6">
              <div className="flex justify-between items-center text-lg">
                <span className="font-semibold">Base Rate (60-Min Session)</span>
                <span className="font-bold">${basePrice}</span>
              </div>
              <hr className="border-alpine-dark border-opacity-10"/>

              {addons.map(addon => (
                <div key={addon.id} className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold">{addon.name}</h4>
                    <p className="text-sm text-stone">{addon.description}</p>
                  </div>
                  {addon.max > 1 ? (
                    <div className="flex items-center gap-2 border border-alpine-dark border-opacity-10 rounded-base">
                      <button onClick={() => dispatch({ type: 'decrement', id: addon.id })} className="p-2 text-stone hover:text-glacial-blue" aria-label={`Decrease ${addon.name}`}>
                        <Minus size={16} />
                      </button>
                      <span className="w-8 text-center font-semibold">{addon.quantity}</span>
                      <button onClick={() => dispatch({ type: 'increment', id: addon.id })} className="p-2 text-stone hover:text-glacial-blue" aria-label={`Increase ${addon.name}`}>
                        <Plus size={16} />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => dispatch({ type: 'toggle', id: addon.id })}
                      role="switch"
                      aria-checked={addon.quantity > 0}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        addon.quantity > 0 ? 'bg-glacial-blue' : 'bg-stone bg-opacity-30'
                      }`}
                    >
                      <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        addon.quantity > 0 ? 'translate-x-6' : 'translate-x-1'
                      }`} />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </SoftCard>
          
          <div className="sticky top-24">
            <SoftCard className="bg-white border-2 border-alpine-dark border-opacity-10">
              <h3 className="text-2xl font-heading font-bold mb-6 text-alpine-dark">Your Custom Adventure</h3>
              <div className="space-y-4">
                <div className="flex justify-between text-lg text-alpine-dark">
                  <span>Base Rate</span>
                  <span>${basePrice}</span>
                </div>
                {addons.filter(a => a.quantity > 0).map(addon => (
                  <div key={addon.id} className="flex justify-between text-stone">
                    <span>{addon.name} {addon.quantity > 1 ? `x ${addon.quantity}` : ''}</span>
                    <span>+${addon.price * addon.quantity}</span>
                  </div>
                ))}
                <hr className="border-alpine-dark border-opacity-10"/>
                <div className="flex justify-between text-3xl font-heading font-bold pt-4 text-alpine-dark">
                  <span>Total</span>
                  <span>${totalPrice}</span>
                </div>
              </div>
              <Button 
                onClick={() => navigate('contact', { 
                  package: 'Custom Build', 
                  price: totalPrice, 
                  items: addons.filter(a => a.quantity > 0).map(a => `${a.name} (x${a.quantity})`) 
                })} 
                variant="primary" 
                size="lg" 
                className="w-full mt-8"
              >
                Request This Date
              </Button>
            </SoftCard>
          </div>
        </div>
      </Section>
      
      <LeadMagnetSection />
    </main>
  );
}