import React from 'react';
import { Camera, Aperture, MountainSnow, Backpack, Compass, Map } from 'lucide-react';
import { Section } from '../components/Section';
import { SectionHeader } from '../components/SectionHeader';
import { SoftCard } from '../components/SoftCard';

export function AboutPage() {
  return (
    <main>
      <Section id="about-hero">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-24 items-center">
          <div>
            <SectionHeader title="Your Guide (With the Ikon Pass)" subtitle="About Me" align="left" />
            <p className="text-stone mb-4 text-lg">
              Hey, I'm Anton. I'm not just a photographer—I'm an adventurer first, storyteller second.
            </p>
            <p className="text-stone mb-4">
              For the past 10 years, I've been chasing sunrises from mountain summits, sleeping under the stars in my backpack, and exploring every corner of the Colorado Rockies on my snowboard. My love for the outdoors started with hiking—those long backcountry trails where you forget what day it is and just... exist. Then came the snowboarding obsession. Then the camera.
            </p>
            <p className="text-stone mb-4">
              I realized my best landscape shots were missing something: people. The real magic wasn't just capturing a perfect mountain vista—it was capturing the *moment* someone experiences it for the first time. That gasp when you crest a ridge. The laughter when you wipe out in powder. The tears when your partner says yes at 12,000 feet.
            </p>
            <p className="text-stone mb-4">
              Now, I combine everything I love: outdoor adventure, travel photography, and connecting with people who get it. My gear goes where most photographers won't—I'm the guy hiking three miles off-trail to find the perfect proposal spot, or strapping my camera to my chest to follow you down a double-black run.
            </p>
            <p className="text-stone mb-8">
              When I'm not behind the camera, you'll find me planning my next backpacking trip, waxing my board, or editing photos from a tent somewhere in the Rockies. Let's create something epic together.
            </p>
          </div>
          <div>
            <img
              src="https://images.unsplash.com/photo-1699694927472-46a4fcf68973?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaG90b2dyYXBoZXIlMjBvdXRkb29yJTIwYWR2ZW50dXJlJTIwY2FtZXJhfGVufDF8fHx8MTc2MjkwMTMzNHww&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Anton, the photographer, capturing outdoor adventure moments"
              className="rounded-soft shadow-soft w-full h-full object-cover aspect-square"
            />
          </div>
        </div>
      </Section>

      {/* My Passions */}
      <Section id="my-passions" className="bg-white">
        <SectionHeader title="What Drives Me" subtitle="My Passions" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 stagger-children">
          <SoftCard className="text-center">
            <MountainSnow size={48} className="mx-auto text-glacial-blue mb-4" />
            <h3 className="text-xl font-heading font-bold mb-3">Snowboarding</h3>
            <p className="text-stone">
              My Ikon Pass is my most valuable possession. I've ridden every resort from Winter Park to A-Basin, and I know where the secret powder stashes are.
            </p>
          </SoftCard>
          <SoftCard className="text-center">
            <Backpack size={48} className="mx-auto text-glacial-blue mb-4" />
            <h3 className="text-xl font-heading font-bold mb-3">Backpacking</h3>
            <p className="text-stone">
              Multi-day backcountry trips are my reset button. There's nothing like carrying everything you need on your back and disappearing into the wilderness.
            </p>
          </SoftCard>
          <SoftCard className="text-center">
            <Compass size={48} className="mx-auto text-glacial-blue mb-4" />
            <h3 className="text-xl font-heading font-bold mb-3">Outdoor Travel</h3>
            <p className="text-stone">
              From the Pacific Crest Trail to Patagonia, I'm always planning the next adventure. Travel is education you can't get from books.
            </p>
          </SoftCard>
          <SoftCard className="text-center">
            <Map size={48} className="mx-auto text-glacial-blue mb-4" />
            <h3 className="text-xl font-heading font-bold mb-3">Hiking</h3>
            <p className="text-stone">
              Where it all started. Give me a good trail, some elevation gain, and a summit view, and I'm the happiest person alive.
            </p>
          </SoftCard>
          <SoftCard className="text-center">
            <Camera size={48} className="mx-auto text-glacial-blue mb-4" />
            <h3 className="text-xl font-heading font-bold mb-3">Landscape Photography</h3>
            <p className="text-stone">
              I spent years perfecting my craft shooting landscapes. Now I blend that technical skill with candid, human storytelling.
            </p>
          </SoftCard>
          <SoftCard className="text-center">
            <Aperture size={48} className="mx-auto text-glacial-blue mb-4" />
            <h3 className="text-xl font-heading font-bold mb-3">Adventure Storytelling</h3>
            <p className="text-stone">
              Your adventure deserves more than a selfie. I capture the feeling, the energy, and the raw emotion of your mountain experience.
            </p>
          </SoftCard>
        </div>
      </Section>

      {/* Personal Gallery */}
      <Section id="personal-gallery">
        <SectionHeader title="My Adventures" subtitle="Beyond The Sessions" />
        <p className="text-center text-stone max-w-2xl mx-auto mb-12">
          When I'm not shooting clients, I'm out here chasing light, testing new gear, and living the life I want to help you document.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="relative h-80 rounded-soft overflow-hidden shadow-soft group">
            <img 
              src="https://images.unsplash.com/photo-1667021901319-ff71b9036cd9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWNrcGFja2VyJTIwaGlraW5nJTIwbW91bnRhaW5zfGVufDF8fHx8MTc2MjkwMTMzM3ww&ixlib=rb-4.1.0&q=80&w=1080" 
              alt="Backpacking through mountain trails"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-alpine-dark via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
              <span className="text-white font-heading font-bold text-xl">Backpacking Adventures</span>
            </div>
          </div>
          <div className="relative h-80 rounded-soft overflow-hidden shadow-soft group">
            <img 
              src="https://images.unsplash.com/photo-1659025671240-54e686180c06?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYW5kc2NhcGUlMjBwaG90b2dyYXBoeSUyMG1vdW50YWluc3xlbnwxfHx8fDE3NjI4NjYxMTF8MA&ixlib=rb-4.1.0&q=80&w=1080" 
              alt="Landscape photography in the mountains"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-alpine-dark via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
              <span className="text-white font-heading font-bold text-xl">Landscape Work</span>
            </div>
          </div>
          <div className="relative h-80 rounded-soft overflow-hidden shadow-soft group">
            <img 
              src="https://images.unsplash.com/photo-1579976378909-3580e222b070?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1964&q=80" 
              alt="Snowboarding with camera gear"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-alpine-dark via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
              <span className="text-white font-heading font-bold text-xl">Snowboarding Life</span>
            </div>
          </div>
        </div>
      </Section>
      
      <Section id="my-gear" className="bg-white">
        <SectionHeader title="My Gear" subtitle="Professional & Mountain-Ready" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <SoftCard>
            <Camera size={48} className="mx-auto text-glacial-blue mb-4" />
            <h3 className="text-xl font-heading font-bold">Pro Camera Body</h3>
            <p className="text-stone mt-2">Weather-sealed mirrorless bodies that handle extreme cold, snow, and altitude like a champ.</p>
          </SoftCard>
          <SoftCard>
            <Aperture size={48} className="mx-auto text-glacial-blue mb-4" />
            <h3 className="text-xl font-heading font-bold">Premium Lenses</h3>
            <p className="text-stone mt-2">Fast, sharp "L-series" glass optimized for action, low light, and breathtaking landscapes.</p>
          </SoftCard>
          <SoftCard>
            <MountainSnow size={48} className="mx-auto text-glacial-blue mb-4" />
            <h3 className="text-xl font-heading font-bold">The Real Gear</h3>
            <p className="text-stone mt-2">Jones snowboard, Ikon Pass, 65L backpack, and a thermos of coffee. Always ready for adventure.</p>
          </SoftCard>
        </div>
      </Section>
    </main>
  );
}