import React from 'react';
import { CheckCircle } from 'lucide-react';
import { Section } from '../components/Section';
import { SectionHeader } from '../components/SectionHeader';
import { SoftCard } from '../components/SoftCard';
import { SnowEffect } from '../components/SnowEffect';

export function ExperiencePage() {
  return (
    <main>
      <Section id="experience-hero" className="p-0 max-w-full h-[70vh] relative flex items-center justify-center text-center">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover z-0"
          poster="https://images.unsplash.com/photo-1542384557-c24e603b54b6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80"
        >
          <source src="https://assets.mixkit.co/videos/preview/mixkit-man-snowboarding-down-a-slope-in-slow-motion-44238-large.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-alpine-dark opacity-40 z-10"></div>
        <SnowEffect />
        <div className="relative z-20">
          <SectionHeader title="This Isn't a Photo Session." subtitle="The Experience" />
          <p className="text-2xl text-snow max-w-3xl mx-auto -mt-8 font-body">
            It's an adventure. It's laughing so hard you cry. It's hot chocolate from a thermos on a summit. And *that's* when I get the shot.
          </p>
        </div>
      </Section>
      
      <Section id="timeline">
        <SectionHeader title="What to Expect" subtitle="The Process" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <SoftCard>
            <h3 className="text-2xl font-heading font-bold mb-4">Before</h3>
            <p className="text-stone mb-4">
              We start with our 20-min "Vibe Check" call. We're not just clients, we're partners. We'll plan the location, the timing, and (for proposals) the secret "legend" to make it flawless.
            </p>
            <ul className="text-stone space-y-2">
              <li className="flex gap-2"><CheckCircle size={18} className="text-glacial-blue" /><span>Location Scouting</span></li>
              <li className="flex gap-2"><CheckCircle size={18} className="text-glacial-blue" /><span>Timeline Planning</span></li>
              <li className="flex gap-2"><CheckCircle size={18} className="text-glacial-blue" /><span>What-to-Wear Guide</span></li>
            </ul>
          </SoftCard>
          <SoftCard>
            <h3 className="text-2xl font-heading font-bold mb-4">During</h3>
            <p className="text-stone mb-4">
              This is the fun part. We meet, we ride, we explore. My camera is just along for the ride. My only rule? No awkward posing. I'll give you prompts that feel like games, not instructions.
            </p>
            <ul className="text-stone space-y-2">
              <li className="flex gap-2"><CheckCircle size={18} className="text-glacial-blue" /><span>No Awkward Posing</span></li>
              <li className="flex gap-2"><CheckCircle size={18} className="text-glacial-blue" /><span>Focus on Real Moments</span></li>
              <li className="flex gap-2"><CheckCircle size={18} className="text-glacial-blue" /><span>Expert Mountain Guide</span></li>
            </ul>
          </SoftCard>
          <SoftCard>
            <h3 className="text-2xl font-heading font-bold mb-4">After</h3>
            <p className="text-stone mb-4">
              You get to re-live the adventure *before your vacation is even over*. I deliver your full, high-resolution digital gallery within 72 hours. Guaranteed.
            </p>
            <ul className="text-stone space-y-2">
              <li className="flex gap-2"><CheckCircle size={18} className="text-glacial-blue" /><span>72-Hour Gallery Delivery</span></li>
              <li className="flex gap-2"><CheckCircle size={18} className="text-glacial-blue" /><span>Full-Res Digital Files</span></li>
              <li className="flex gap-2"><CheckCircle size={18} className="text-glacial-blue" /><span>Easy-to-Use Print Store</span></li>
            </ul>
          </SoftCard>
        </div>
      </Section>
    </main>
  );
}