import React, { useState } from 'react';
import { CheckCircle } from 'lucide-react';
import { useNavigation } from '../contexts/NavigationContext';
import { Section } from '../components/Section';
import { SectionHeader } from '../components/SectionHeader';
import { SoftCard } from '../components/SoftCard';
import { Input } from '../components/Input';
import { Textarea } from '../components/Textarea';
import { Button } from '../components/Button';
import { AccordionItem } from '../components/AccordionItem';

export function ContactPage() {
  const { pageParams } = useNavigation();
  const [formState, setFormState] = useState({
    name: "",
    email: "",
    date: "",
    resort: "Winter Park",
    package: pageParams.package || "Adventure Session",
    message: pageParams.items ? `Custom Build:\n${pageParams.items.join('\n')}\nTotal: $${pageParams.price}` : "",
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { id, value } = e.target;
    setFormState(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form Submitted:", formState);
    setIsSubmitted(true);
  };

  return (
    <main>
      <Section id="contact-hero" className="text-center">
        <SectionHeader title="Let's Plan Your Adventure" subtitle="Contact Me" />
        <p className="text-lg text-stone max-w-2xl mx-auto">
          Dates for the 2024/2025 season are filling fast. Fill out the form below, and I'll get back to you within 24 hours to schedule our "Vibe Check" call.
        </p>
      </Section>
      <Section id="contact-form" className="pt-0">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12">
          <div className="md:col-span-7">
            {isSubmitted ? (
              <SoftCard className="text-center">
                <CheckCircle size={48} className="mx-auto text-glacial-blue mb-4" />
                <h3 className="text-2xl font-heading font-bold">Message Sent!</h3>
                <p className="text-stone mt-2">Thanks for reaching out! I'll be in touch within 24 hours to plan your adventure.</p>
              </SoftCard>
            ) : (
              <SoftCard as="form" onSubmit={handleSubmit}>
                <h3 className="text-2xl font-heading font-bold mb-6">Booking Inquiry</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <Input label="Your Name" id="name" value={formState.name} onChange={handleChange} required />
                  <Input label="Your Email" id="email" type="email" value={formState.email} onChange={handleChange} required />
                  <Input label="Desired Date" id="date" type="date" value={formState.date} onChange={handleChange} />
                  <div>
                    <label htmlFor="resort" className="block text-sm font-medium text-stone mb-2">Resort</label>
                    <select id="resort" value={formState.resort} onChange={handleChange} className="w-full p-3 bg-white border border-alpine-dark border-opacity-10 rounded-base shadow-soft text-alpine-dark focus:outline-none focus:ring-2 focus:ring-glacial-blue">
                      <option>Winter Park</option>
                      <option>Copper Mountain</option>
                      <option>Arapahoe Basin</option>
                      <option>Other Ikon Resort</option>
                    </select>
                  </div>
                  <div className="sm:col-span-2">
                    <Input label="Package of Interest" id="package" value={formState.package} onChange={handleChange} />
                  </div>
                  <div className="sm:col-span-2">
                    <Textarea label="Your Message" id="message" placeholder="Tell me about your trip, your vision, or any questions you have!" value={formState.message} onChange={handleChange} />
                  </div>
                  <div className="sm:col-span-2">
                    <Button type="submit" variant="primary" size="lg" className="w-full">
                      Send Inquiry
                    </Button>
                  </div>
                </div>
              </SoftCard>
            )}
          </div>
          <div className="md:col-span-5">
            <h3 className="text-2xl font-heading font-bold mb-6">Frequently Asked Questions</h3>
            <div className="space-y-2">
              <AccordionItem title="What if the weather is bad?">
                We embrace it! Some of the most epic, moody photos come from snowy days. If it's a full-on blizzard, we can reschedule to another day during your trip, no problem.
              </AccordionItem>
              <AccordionItem title="How do we get around the mountain?">
                We ride! I'm on my snowboard, you're on your skis/board. We'll use the lifts and ride to the spots. All locations are easily accessible from blue runs.
              </AccordionItem>
              <AccordionItem title="We're awkward in photos...">
                Perfect! I don't do "posing." I do "prompts." I'll ask you to play games, whisper secrets, and laugh. My job is to capture *your* real connection, not a fake one.
              </AccordionItem>
              <AccordionItem title="How do we book?">
                A 50% non-refundable deposit is required to secure your date. The remaining 50% is due one week before your session.
              </AccordionItem>
            </div>
          </div>
        </div>
      </Section>
    </main>
  );
}
