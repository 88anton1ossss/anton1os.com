import React, { useState, useRef } from 'react';
import { Loader2, Wand2, Sparkles, Instagram } from 'lucide-react';
import { Section } from '../components/Section';
import { SectionHeader } from '../components/SectionHeader';
import { SoftCard } from '../components/SoftCard';
import { Input } from '../components/Input';
import { Button } from '../components/Button';

export function AIToolsPage() {
  const [proposalResult, setProposalResult] = useState("");
  const [proposalLoading, setProposalLoading] = useState(false);
  const proposalLocationRef = useRef<HTMLInputElement>(null);
  const proposalVibeRef = useRef<HTMLInputElement>(null);

  const [captionResult, setCaptionResult] = useState("");
  const [captionLoading, setCaptionLoading] = useState(false);
  const captionDescRef = useRef<HTMLInputElement>(null);
  const captionMoodRef = useRef<HTMLInputElement>(null);
  const captionCtaRef = useRef<HTMLInputElement>(null);

  const callGemini = async (systemPrompt: string, userQuery: string, setLoading: (v: boolean) => void, setResult: (v: string) => void) => {
    setLoading(true);
    setResult("");
    const apiKey = "";
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=${apiKey}`;

    const payload = {
      contents: [{ parts: [{ text: userQuery }] }],
      systemInstruction: { parts: [{ text: systemPrompt }] },
    };

    let retryCount = 0;
    while (retryCount < 3) {
      try {
        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        if (!response.ok) {
          if (response.status === 429) {
            const delay = Math.pow(2, retryCount) * 1000;
            console.warn(`Rate limited. Retrying in ${delay}ms...`);
            await new Promise(resolve => setTimeout(resolve, delay));
            retryCount++;
            continue;
          }
          throw new Error(`API Error: ${response.statusText}`);
        }

        const result = await response.json();
        const candidate = result.candidates?.[0];

        if (candidate && candidate.content?.parts?.[0]?.text) {
          const formattedText = candidate.content.parts[0].text
            .replace(/^Here are.*/i, '<h3 class="text-2xl font-heading font-bold mb-4">Here are a few ideas I\'ve scouted...</h3>')
            .replace(/Option 1:/g, '<h4 class="text-xl font-heading font-bold mt-4 mb-2">Option 1:</h4>')
            .replace(/Option 2:/g, '<h4 class="text-xl font-heading font-bold mt-6 mb-2">Option 2:</h4>')
            .replace(/Option 3:/g, '<h4 class="text-xl font-heading font-bold mt-6 mb-2">Option 3:</h4>')
            .replace(/\n\n/g, '</p><p class="mt-4">')
            .replace(/\n/g, '<br>');
          setResult(formattedText);
        } else {
          setResult("<p class='text-red-600'>Sorry, I couldn't generate ideas at this time. Please try again.</p>");
        }
        break;
        
      } catch (error) {
        console.error("Gemini API error:", error);
        if (retryCount >= 2) {
          setResult(`<p class='text-red-600'>Error: ${error instanceof Error ? error.message : 'Unknown error'}. Please try again later.</p>`);
        }
        const delay = Math.pow(2, retryCount) * 1000;
        await new Promise(resolve => setTimeout(resolve, delay));
        retryCount++;
      }
    }
    setLoading(false);
  };

  const handleProposalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const location = proposalLocationRef.current?.value || 'Colorado mountain';
    const vibe = proposalVibeRef.current?.value || 'epic and adventurous';
    const systemPrompt = `You are a creative guide and expert proposal planner for anton1os.com, a high-end adventure photographer in Colorado. Your name is Anton, and you are a snowboarder. Your job is to brainstorm unique, epic, and highly photogenic proposal ideas.
    Guidelines:
    - Generate 3 distinct ideas.
    - Keep each idea short (2-3 sentences).
    - Make them sound adventurous, personal, and memorable.
    - Always incorporate the location and vibe requested.
    - Frame them as "Here are a few ideas I've scouted..."
    - Be encouraging and friendly.`;
    const userQuery = `Generate 3 distinct proposal ideas for a client.
    - Location: ${location}
    - Vibe: ${vibe}`;
    
    callGemini(systemPrompt, userQuery, setProposalLoading, setProposalResult);
  };

  const handleCaptionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const description = captionDescRef.current?.value || 'an epic photo in the mountains';
    const mood = captionMoodRef.current?.value || 'adventurous';
    const cta = captionCtaRef.current?.value || 'book a session';
    const systemPrompt = `You are a world-class social media manager for anton1os.com, a high-end adventure photographer. Your name is Anton. Your job is to write engaging, authentic, and non-cheesy Instagram captions.
    Guidelines:
    - Generate 3 distinct caption options (Option 1, Option 2, Option 3).
    - Each option should be 2-4 sentences long.
    - Use storytelling. Be personal ("I", "my clients").
    - Seamlessly weave in the photo description, mood, and the requested Call to Action (CTA).
    - Include a block of 5-7 relevant, niche hashtags at the end (e.g., #coloradophotographer, #adventureengagement, #ikonpass, #winterpark).`;
    const userQuery = `Generate 3 Instagram caption options.
    - Photo Description: ${description}
    - Mood: ${mood}
    - Call to Action: ${cta}`;

    callGemini(systemPrompt, userQuery, setCaptionLoading, setCaptionResult);
  };

  return (
    <main>
      <Section id="ai-tools-hero" className="text-center">
        <SectionHeader title="AI Adventure Tools" subtitle="Exclusively for You" />
        <p className="text-lg text-stone max-w-2xl mx-auto">
          I'm not just a photographer, I'm your guide. Use my custom AI tools to plan your proposal or even help you write your next Instagram post.
        </p>
      </Section>
      
      <Section id="proposal-generator" className="bg-white">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <SectionHeader title="Need an Epic Proposal Idea?" subtitle="Proposal Generator" align="left" />
            <p className="text-stone mb-6">Tell me the location and the vibe, and I'll brainstorm a few epic, photogenic ideas for you based on my experience.</p>
            <form onSubmit={handleProposalSubmit} className="space-y-4">
              <Input label="Location" id="prop-location" ref={proposalLocationRef} placeholder="e.g., Winter Park, A-Basin..." />
              <Input label="Vibe" id="prop-vibe" ref={proposalVibeRef} placeholder="e.g., quiet, adventurous, epic sunrise..." />
              <Button type="submit" variant="primary" size="lg" disabled={proposalLoading}>
                {proposalLoading ? <Loader2 className="animate-spin" /> : <Wand2 size={18} />}
                {proposalLoading ? "Generating..." : "Generate Ideas"}
              </Button>
            </form>
          </div>
          <SoftCard className="min-h-[20rem]">
            {proposalLoading && (
              <div className="flex flex-col items-center justify-center h-full">
                <Loader2 size={48} className="animate-spin text-glacial-blue" />
                <p className="text-stone mt-4">Crafting your epic moment...</p>
              </div>
            )}
            {proposalResult && (
              <div className="prose" dangerouslySetInnerHTML={{ __html: proposalResult }} />
            )}
            {!proposalLoading && !proposalResult && (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <Sparkles size={48} className="text-stone opacity-50" />
                <p className="text-stone mt-4">Your custom proposal ideas will appear here.</p>
              </div>
            )}
          </SoftCard>
        </div>
      </Section>

      <Section id="caption-generator" className="bg-alpine-dark text-snow">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <SoftCard className="min-h-[20rem] order-2 md:order-1 bg-alpine-dark border-snow border-opacity-20">
            {captionLoading && (
              <div className="flex flex-col items-center justify-center h-full">
                <Loader2 size={48} className="animate-spin text-glacial-blue" />
                <p className="text-stone mt-4">Writing your captions...</p>
              </div>
            )}
            {captionResult && (
              <div className="prose prose-invert" dangerouslySetInnerHTML={{ __html: captionResult }} />
            )}
            {!captionLoading && !captionResult && (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <Instagram size={48} className="text-stone opacity-50" />
                <p className="text-stone mt-4">Your Instagram captions will appear here.</p>
              </div>
            )}
          </SoftCard>
          <div className="order-1 md:order-2">
            <SectionHeader title="Need an Instagram Caption?" subtitle="Social Media Helper" align="left" />
            <p className="text-stone mb-6">Describe your photo, the mood, and your goal, and I'll write a few authentic options for you. (This one's for you, fellow creatives!)</p>
            <form onSubmit={handleCaptionSubmit} className="space-y-4">
              <Input label="Photo Description" id="cap-desc" ref={captionDescRef} placeholder="e.g., couple laughing at sunset, Copper Mtn" />
              <Input label="Mood" id="cap-mood" ref={captionMoodRef} placeholder="e.g., romantic, epic, fun, nostalgic" />
              <Input label="Call to Action (CTA)" id="cap-cta" ref={captionCtaRef} placeholder="e.g., 'book your session', 'tag a friend'" />
              <Button type="submit" variant="primary" size="lg" disabled={captionLoading}>
                {captionLoading ? <Loader2 className="animate-spin" /> : <Wand2 size={18} />}
                {captionLoading ? "Writing..." : "Generate Captions"}
              </Button>
            </form>
          </div>
        </div>
      </Section>
    </main>
  );
}
