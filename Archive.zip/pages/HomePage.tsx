import React from 'react';
import { useNavigation } from '../contexts/NavigationContext';
import { Section } from '../components/Section';
import { SectionHeader } from '../components/SectionHeader';
import { GlassmorphismCard } from '../components/GlassmorphismCard';
import { SoftCard } from '../components/SoftCard';
import { Button } from '../components/Button';
import { PackageCard } from '../components/PackageCard';
import { BlogCard } from '../components/BlogCard';
import { SnowEffect } from '../components/SnowEffect';
import { TestimonialsSection } from '../components/TestimonialsSection';
import { packagesData } from '../data/packages';
import { blogPostsData } from '../data/blog';
import { MessageSquare, MountainSnow, Sparkles, Aperture, MapPin } from 'lucide-react';
import { LeadMagnetModal } from '../components/LeadMagnetModal';

export function HomePage() {
  const { navigate } = useNavigation();

  const HeroSection = () => (
    <div className="relative w-full h-screen flex items-center justify-center p-6 md:p-12 overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1549216666-be38740d26e4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
          alt="Epic mountain landscape"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-alpine-dark opacity-40"></div>
      </div>

      {/* Snow Effect */}
      <SnowEffect />

      {/* Content Card */}
      <GlassmorphismCard className="relative z-20 w-full max-w-3xl text-center">
        <h1 className="text-lg md:text-xl font-heading font-semibold uppercase tracking-wider text-alpine-dark mb-4">
          On-Mountain Adventure & Proposal Photographer
        </h1>
        <h2 className="text-4xl md:text-6xl font-heading font-bold uppercase tracking-wider text-alpine-dark">
          Stop Taking
          <br />
          Ugly Ski Selfies.
        </h2>
        <p className="mt-6 text-lg md:text-xl font-body text-alpine-dark max-w-lg mx-auto">
          You're spending $5,000 on a Colorado ski trip. Don't let your memories be blurry phone photos. I'm an on-mountain photographer & snowboarder (with an Ikon Pass) ready to capture your adventure.
        </p>
        <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
          <Button onClick={() => navigate('packages')} variant="primary" size="lg">
            See Packages
          </Button>
          <Button onClick={() => navigate('packages', { scrollTo: 'proposal' })} variant="secondary" size="lg" className="bg-glass border-alpine-dark text-alpine-dark hover:bg-alpine-dark hover:text-snow">
            Plan a Proposal
          </Button>
        </div>
      </GlassmorphismCard>
    </div>
  );

  const SocialProofSection = () => (
    <div className="bg-snow py-12">
      <div className="max-w-6xl mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center text-center">
          <div className="flex flex-col items-center gap-2 text-stone">
            <img src="https://images.squarespace-cdn.com/content/v1/6215714e323c2a63e9f4700d/a7c50543-c052-45e0-b74d-17688b13970b/IKON_PASS_Logo_Hero_Black_No-Subtext.png?format=1500w" alt="Ikon Pass Logo" className="h-10 opacity-60" />
            <span className="text-sm font-semibold">Official Ikon Pass Holder</span>
          </div>
          <div className="flex flex-col items-center gap-2 text-stone">
            <Aperture size={32} className="opacity-60" />
            <span className="text-sm font-semibold">10+ Years Experience</span>
          </div>
          <div className="flex flex-col items-center gap-2 text-stone">
            <MapPin size={32} className="opacity-60" />
            <span className="text-sm font-semibold">Winter Park Expert</span>
          </div>
          <div className="flex flex-col items-center gap-2 text-stone">
            <MountainSnow size={32} className="opacity-60" />
            <span className="text-sm font-semibold">Copper & A-Basin Guide</span>
          </div>
        </div>
      </div>
    </div>
  );

  const HowItWorksSection = () => {
    const steps = [
      { id: 1, title: "1. The 'Vibe Check' Call", description: "We hop on a 20-min Zoom call to plan your vision, the secret location (for proposals), and the perfect time of day.", icon: <MessageSquare /> },
      { id: 2, title: "2. The On-Mountain Adventure", description: "We meet at the lift. I'm just 'another snowboarder'. We ride, find our spots, and capture epic, natural moments. No stress.", icon: <MountainSnow /> },
      { id: 3, title: "3. The 72-Hour Gallery", description: "You get a full high-resolution digital gallery to download and share *before* your vacation is even over.", icon: <Sparkles /> }
    ];
    return (
      <Section id="how-it-works">
        <SectionHeader title="How It Works (It's Easy)" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 stagger-children">
          {steps.map(step => (
            <SoftCard key={step.id} className="text-center">
              <div className="w-16 h-16 bg-glacial-blue text-snow rounded-full flex items-center justify-center mx-auto">
                {React.cloneElement(step.icon, { size: 32 })}
              </div>
              <h3 className="text-xl font-heading font-bold mt-6 mb-3">{step.title}</h3>
              <p className="text-stone">{step.description}</p>
            </SoftCard>
          ))}
        </div>
      </Section>
    );
  };

  const PackageTeaserSection = () => (
    <Section id="packages-teaser" className="bg-white">
      <SectionHeader title="Choose Your Adventure" subtitle="Packages" />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 stagger-children">
        <PackageCard
          pkg={packagesData[0]}
          ctaText="Learn More"
          onCtaClick={() => navigate("packages", { scrollTo: "solo" })}
        />
        <PackageCard
          pkg={packagesData[1]}
          ctaText="Learn More"
          onCtaClick={() => navigate("packages", { scrollTo: "adventure" })}
          isFeatured={true}
        />
        <PackageCard
          pkg={packagesData[2]}
          ctaText="Learn More"
          onCtaClick={() => navigate("packages", { scrollTo: "proposal" })}
        />
      </div>
      <div className="text-center mt-12">
        <Button onClick={() => navigate('packages')} variant="primary" size="lg">
          View All Packages
        </Button>
      </div>
    </Section>
  );

  const AboutTeaser = () => (
    <Section id="about-teaser">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-24 items-center">
        <div className="order-2 md:order-1">
          <SectionHeader title="Your Guide (With the Ikon Pass)" subtitle="About Me" align="left" />
          <p className="text-stone mb-4">
            Hey, I'm Anton. I'm not just a photographer—I'm an avid snowboarder. I spent years capturing Colorado's landscapes, but I realized the real story was the people *in* those landscapes.
          </p>
          <p className="text-stone mb-8">
            My camera (and my Ikon Pass) are ready. I know where to be at 10 AM for the best light at Winter Park and how to avoid the crowds at Copper. Let's get the shot.
          </p>
          <Button onClick={() => navigate('about')} variant="secondary">
            More About Me
          </Button>
        </div>
        <div className="order-1 md:order-2">
          <img
            src="https://images.unsplash.com/photo-1579976378909-3580e222b070?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1964&q=80"
            alt="Anton, the photographer, on a snowboard with a camera"
            className="rounded-soft shadow-soft w-full h-full object-cover aspect-square"
          />
        </div>
      </div>
    </Section>
  );

  const BlogTeaser = () => (
    <Section id="blog-teaser" className="bg-white">
      <SectionHeader title="From The Blog" subtitle="Guides & Tips" />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 stagger-children">
        {blogPostsData.slice(0, 3).map(post => (
          <BlogCard key={post.id} post={post} />
        ))}
      </div>
      <div className="text-center mt-12">
        <Button onClick={() => navigate('blog')} variant="secondary">
          View All Posts
        </Button>
      </div>
    </Section>
  );

  const FinalCTA = () => (
    <Section id="final-cta" className="bg-alpine-dark text-center text-snow">
      <h2 className="text-3xl md:text-5xl font-heading font-bold">
        Ready to Capture Your Adventure?
      </h2>
      <p className="max-w-xl mx-auto mt-4 text-lg text-stone">
        Winter 2024/2025 dates are booking fast. Let's get your date on the calendar.
      </p>
      <Button onClick={() => navigate('contact')} variant="primary" size="lg" className="mt-8">
        Check Availability
      </Button>
    </Section>
  );
  
  return (
    <main>
      <LeadMagnetModal />
      <HeroSection />
      <SocialProofSection />
      <HowItWorksSection />
      <PackageTeaserSection />
      <TestimonialsSection />
      <AboutTeaser />
      <BlogTeaser />
      <FinalCTA />
    </main>
  );
}