import React from 'react';
import { Section } from '../components/Section';
import { SectionHeader } from '../components/SectionHeader';
import { BlogCard } from '../components/BlogCard';
import { LeadMagnetSection } from '../components/LeadMagnetSection';
import { blogPostsData } from '../data/blog';

export function BlogPage() {
  return (
    <main>
      <Section id="blog-hero" className="text-center">
        <SectionHeader title="Guides & Tips" subtitle="From The Blog" />
        <p className="text-lg text-stone max-w-2xl mx-auto">
          Planning guides, insider tips, and stories from the slopes.
        </p>
      </Section>
      <Section id="blog-grid" className="bg-white">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPostsData.map(post => (
            <BlogCard key={post.id} post={post} />
          ))}
        </div>
      </Section>
      <LeadMagnetSection />
    </main>
  );
}