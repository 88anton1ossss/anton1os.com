import React, { useState } from 'react';
import { X } from 'lucide-react';
import { Section } from '../components/Section';
import { SectionHeader } from '../components/SectionHeader';
import { portfolioImages, categories } from '../data/portfolio';

export function PortfolioPage() {
  const [filter, setFilter] = useState('All');
  const [lightboxImage, setLightboxImage] = useState<typeof portfolioImages[0] | null>(null);

  const filteredImages =
    filter === "All"
      ? portfolioImages
      : portfolioImages.filter((img) => img.category === filter);

  const openLightbox = (img: typeof portfolioImages[0]) => setLightboxImage(img);
  const closeLightbox = () => setLightboxImage(null);

  return (
    <main>
      <Section id="portfolio-hero" className="text-center">
        <SectionHeader title="The Vibe" subtitle="Portfolio" />
        <p className="text-lg text-stone max-w-2xl mx-auto">
          This isn't a cheesy studio. This is real adventure, real moments, and epic backdrops.
        </p>
      </Section>
      
      <div className="w-full flex justify-center items-center gap-2 md:gap-4 px-6 mb-12">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setFilter(cat)}
            className={`py-2 px-4 rounded-full text-sm font-semibold transition-all ${
              filter === cat
                ? 'bg-glacial-blue text-snow'
                : 'bg-white text-stone hover:bg-snow'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>
      
      <div className="max-w-6xl mx-auto px-6 lg:px-12 pb-24">
        <div className="columns-1 md:columns-2 lg:columns-3 gap-6">
          {filteredImages.map((img, index) => (
            <button
              key={img.id + '-' + index}
              onClick={() => openLightbox(img)}
              className="block w-full mb-6 rounded-soft overflow-hidden shadow-soft transition-transform duration-300 hover:scale-[1.02] focus-visible:scale-[1.02]"
              aria-label={`View image: ${img.alt}`}
            >
              <img src={img.src} alt={img.alt} className="w-full h-auto object-cover" loading="lazy" />
            </button>
          ))}
        </div>
      </div>
      
      {lightboxImage && (
        <div
          className="fixed inset-0 z-50 bg-alpine-dark bg-opacity-90 flex items-center justify-center p-4"
          onClick={closeLightbox}
          role="dialog"
          aria-modal="true"
          aria-label="Image lightbox"
        >
          <button
            onClick={closeLightbox}
            className="absolute top-6 right-6 text-snow opacity-70 hover:opacity-100"
            aria-label="Close lightbox"
          >
            <X size={32} />
          </button>
          <img
            src={lightboxImage.src}
            alt={lightboxImage.alt}
            className="max-w-full max-h-[90vh] object-contain rounded-lg"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </main>
  );
}
